README:
Instuctions to run:

Step1: Create a project in Eclipse IDE.
Step2: Add files Asgmt1.java and Asgmt1TestCase.java
Step3: Download junit jar file from http://heanet.dl.sourceforge.net/project/junit/junit/4.10/junit-4.10.jar
Step4: Add junit-4.10.jar as a external jar >right-click project>properties>Libaries>Add External Jar
Step5: Run as JUnit Test.

All functions are in Asgmt1.java and test cases are in Asgmt1TestCase.java